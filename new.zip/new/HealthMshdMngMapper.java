package com.sds.seas.biz.health.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.RowBounds;

import com.sds.seas.biz.health.dvo.HealthMshdMngDVO;
import com.sds.sflex.common.docs.dvo.AttachFileDVO;

/**
 * @name        : HealthMshdMngMapper
 * @description : Health MS(H)D Management Mapper
 */
@Mapper
public interface HealthMshdMngMapper {

    /**
     * @dmlType Insert
     * @name    : insertHealthMshdMng
     * @param   : HealthMshdMngDVO
     * @return  : int
     */
    int insertHealthMshdMng(HealthMshdMngDVO dvo);

    /**
     * @dmlType Select
     * @name    : selectHealthMshdMngList
     * @param   : HealthMshdMngDVO (contains search parameters)
     * @param   : RowBounds (for pagination)
     * @return  : List<HealthMshdMngDVO>
     */
    List<HealthMshdMngDVO> selectHealthMshdMngList(HealthMshdMngDVO dvo, RowBounds rowBounds);

    /**
     * @dmlType Select
     * @name    : selectHealthMshdMngDetail
     * @param   : String mshdobjUid (Primary key)
     * @return  : HealthMshdMngDVO
     */
    HealthMshdMngDVO selectHealthMshdMngDetail(String mshdobjUid);

    /**
     * @dmlType Update
     * @name    : updateHealthMshdMng
     * @param   : HealthMshdMngDVO
     * @return  : int
     */
    int updateHealthMshdMng(HealthMshdMngDVO dvo);

    /**
     * @dmlType Delete
     * @name    : deleteHealthMshdMng
     * @param   : String mshdobjUid (Primary key)
     * @return  : int
     */
    int deleteHealthMshdMng(String mshdobjUid);

    /**
     * @dmlType Select
     * @name    : selectAttachFilesByDocId
     * @param   : String atthDocId
     * @return  : List<AttachFileDVO>
     */
    List<AttachFileDVO> selectAttachmentsByDocIds(List<String> docIds);
}

