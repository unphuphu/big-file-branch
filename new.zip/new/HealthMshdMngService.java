package com.sds.seas.biz.health.service.impl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sds.seas.biz.health.dvo.HealthMshdMngDVO;
import com.sds.seas.biz.health.mapper.HealthMshdMngMapper;
import com.sds.seas.biz.health.service.IHealthMshdMngService;
import com.sds.sflex.common.common.dvo.UserSessionDVO;
import com.sds.sflex.common.utils.DateUtil;
import com.sds.sflex.common.utils.IDGenUtil;
import com.sds.sflex.system.config.context.SFLEXContextHolder;
import com.sds.sflex.system.config.exception.BizException;
import com.sds.sflex.common.docs.dvo.AttachFileDVO;

@Service("healthMshdMngService")
public class HealthMshdMngService implements IHealthMshdMngService {

    private static final int MAX_TEXT_255 = 255;
    private static final DateTimeFormatter BASIC_DATE = DateTimeFormatter.BASIC_ISO_DATE; // YYYYMMDD

    @Autowired
    private HealthMshdMngMapper mapper;

    @Override
    @Transactional
    public HealthMshdMngDVO insertHealthMshdMng(HealthMshdMngDVO dvo) throws Exception {
        validateCreate(dvo);

        dvo.setMshdobjUid(IDGenUtil.getUUID("MSH"));

        // Prevent DB default('N') from being overridden by null.
        dvo.setSpecManaMatYn(StringUtils.defaultIfBlank(dvo.getSpecManaMatYn(), "N").toUpperCase());
        dvo.setAtthDocId(StringUtils.trimToNull(dvo.getAtthDocId()));

//        applySystemFieldsForInsert(dvo);

        mapper.insertHealthMshdMng(dvo);
        return dvo;
    }

    @Override
    public List<HealthMshdMngDVO> selectHealthMshdMngList(HealthMshdMngDVO dvo) throws Exception {
        if (dvo == null) {
            throw new BizException("MSG_ALT_CONFIRM_INPUT");
        }

        // Trim whitespace from optional string filters
        dvo.setMatNm(StringUtils.trimToNull(dvo.getMatNm()));
        dvo.setSupNm(StringUtils.trimToNull(dvo.getSupNm()));
        dvo.setCasNo(StringUtils.trimToNull(dvo.getCasNo()));
        dvo.setSpecManaMatYn(StringUtils.trimToNull(dvo.getSpecManaMatYn()));

        // Validate date ranges if provided
        if (StringUtils.isNotBlank(dvo.getRegistStartDt())) {
            validateDateYYYYMMDD(dvo.getRegistStartDt(), "registStartDt");
        }
        if (StringUtils.isNotBlank(dvo.getRegistEndDt())) {
            validateDateYYYYMMDD(dvo.getRegistEndDt(), "registEndDt");
        }

        if (StringUtils.isNotBlank(dvo.getRevStartDt())) {
            validateDateYYYYMMDD(dvo.getRevStartDt(), "revStartDt");
        }
        if (StringUtils.isNotBlank(dvo.getRevEndDt())) {
            validateDateYYYYMMDD(dvo.getRevEndDt(), "revEndDt");
        }

        // Get RowBounds for pagination from PagingDVO
        RowBounds rowBounds = dvo.getRowBounds();

        List<HealthMshdMngDVO> resultList = mapper.selectHealthMshdMngList(dvo, rowBounds);

//        // For each record, load attached files
//        if (resultList != null && !resultList.isEmpty()) {
//            for (HealthMshdMngDVO item : resultList) {
//                loadAttachedFiles(item);
//            }
//        }


        if (resultList == null || resultList.isEmpty()) {
            return resultList;
        }

// 1. extract docIds
        List<String> docIds = resultList.stream()
                .map(HealthMshdMngDVO::getAtthDocId)
                .filter(Objects::nonNull)
                .distinct()
                .toList();

// 2. no attachment case
        if (docIds.isEmpty()) {
            resultList.forEach(item -> item.setAttachments(Collections.emptyList()));
            return resultList;
        }

// 3. query attachments
        List<AttachFileDVO> files = mapper.selectAttachmentsByDocIds(docIds);

// 🔥 4. SAFE grouping (quan trọng nhất)
        Map<String, List<AttachFileDVO>> fileMap =
                files.stream()
                        .filter(Objects::nonNull)
                        .filter(f -> f.getAttachDocumentId() != null)
                        .collect(Collectors.groupingBy(AttachFileDVO::getAttachDocumentId));

// 5. set lại cho tất cả item (kể cả empty)
        for (HealthMshdMngDVO item : resultList) {
            item.setAttachments(
                    fileMap.getOrDefault(item.getAtthDocId(), Collections.emptyList())
            );
        }

        return resultList;
    }

    @Override
    public HealthMshdMngDVO selectHealthMshdMngDetail(String mshdobjUid) throws Exception {
        if (StringUtils.isBlank(mshdobjUid)) {
            throw new BizException("MSG_ALT_CONFIRM_INPUT");
        }

        HealthMshdMngDVO dvo = mapper.selectHealthMshdMngDetail(mshdobjUid);
        if (dvo != null) {
            loadAttachedFiles(dvo);
        }
        return dvo;
    }

    @Override
    @Transactional
    public int updateHealthMshdMng(HealthMshdMngDVO dvo) throws Exception {
        if (dvo == null || StringUtils.isBlank(dvo.getMshdobjUid())) {
            throw new BizException("MSG_ALT_CONFIRM_INPUT");
        }

        validateUpdate(dvo);

        // Prevent DB default('N') from being overridden by null.
        dvo.setSpecManaMatYn(StringUtils.defaultIfBlank(dvo.getSpecManaMatYn(), "N").toUpperCase());
        dvo.setAtthDocId(StringUtils.trimToNull(dvo.getAtthDocId()));

        return mapper.updateHealthMshdMng(dvo);
    }

    @Override
    @Transactional
    public int deleteHealthMshdMng(String mshdobjUid) throws Exception {
        if (StringUtils.isBlank(mshdobjUid)) {
            throw new BizException("MSG_ALT_CONFIRM_INPUT");
        }

        return mapper.deleteHealthMshdMng(mshdobjUid);
    }

    /**
     * Load attached files from t_cmd_atth_file_d table using atth_doc_id
     */
    private void loadAttachedFiles(HealthMshdMngDVO dvo) {
        if (dvo != null && StringUtils.isNotBlank(dvo.getAtthDocId())) {
            //dvo.setAttachments(mapper.selectAttachFilesByDocId(dvo.getAtthDocId()));
        }
    }

//    private void applySystemFieldsForInsert(HealthMshdMngDVO dvo) {
//        Long now = DateUtil.getNow();
//        String nowDtm = DateUtil.getDate(now); // YYYYMMDDHHMMSS
//
//        UserSessionDVO session = null;
//        try {
//            session = SFLEXContextHolder.getContext().getUserSession();
//        } catch (Exception ignore) {
//            // keep null
//        }
//
//        String userId = (session != null && StringUtils.isNotBlank(session.getUserId()))
//                ? session.getUserId()
//                : "SYSTEM";
//
//        // Some environments fill these via interceptor; keep any non-blank values already set.
//        dvo.setFstRgstDtm(StringUtils.defaultIfBlank(dvo.getFstRgstDtm(), nowDtm));
//        dvo.setFstRgstUsrId(StringUtils.defaultIfBlank(dvo.getFstRgstUsrId(), userId));
//        dvo.setFstRgstPrgId(StringUtils.defaultIfBlank(dvo.getFstRgstPrgId(), "BIZ_API"));
//        dvo.setFnlMdfcDtm(StringUtils.defaultIfBlank(dvo.getFnlMdfcDtm(), nowDtm));
//        dvo.setFnlMdfcUsrId(StringUtils.defaultIfBlank(dvo.getFnlMdfcUsrId(), userId));
//        dvo.setFnlMdfcPrgId(StringUtils.defaultIfBlank(dvo.getFnlMdfcPrgId(), "BIZ_API"));
//    }

    private void validateCreate(HealthMshdMngDVO dvo) {
        if (dvo == null) {
            throw new BizException("MSG_ALT_CONFIRM_INPUT");
        }

        validateNotBlankMax255(dvo.getMatNm());
        validateNotBlankMax255(dvo.getSupNm());
        validateNotBlankMax255(dvo.getCasNo());
        validateRevDateYYYYMMDD(dvo.getRevDate());
    }

    private void validateUpdate(HealthMshdMngDVO dvo) {
        if (dvo == null) {
            throw new BizException("MSG_ALT_CONFIRM_INPUT");
        }

        // Only validate fields if they're being updated (not null)
        if (StringUtils.isNotBlank(dvo.getMatNm())) {
            validateNotBlankMax255(dvo.getMatNm());
        }
        if (StringUtils.isNotBlank(dvo.getSupNm())) {
            validateNotBlankMax255(dvo.getSupNm());
        }
        if (StringUtils.isNotBlank(dvo.getCasNo())) {
            validateNotBlankMax255(dvo.getCasNo());
        }
        if (StringUtils.isNotBlank(dvo.getRevDate())) {
            validateRevDateYYYYMMDD(dvo.getRevDate());
        }
    }

    private void validateNotBlankMax255(String value) {
        if (StringUtils.isBlank(value) || value.length() > MAX_TEXT_255) {
            throw new BizException("MSG_ALT_CONFIRM_INPUT");
        }
    }

    private void validateRevDateYYYYMMDD(String revDate) {
        if (StringUtils.isBlank(revDate)) {
            throw new BizException("MSG_ALT_CONFIRM_INPUT");
        }
        if (!revDate.matches("\\d{8}")) {
            throw new BizException("MSG_ALT_CONFIRM_INPUT");
        }
        try {
            LocalDate.parse(revDate, BASIC_DATE);
        } catch (DateTimeParseException ex) {
            throw new BizException("MSG_ALT_CONFIRM_INPUT");
        }
    }

    private void validateDateYYYYMMDD(String dateStr, String fieldName) {
        if (!dateStr.matches("\\d{8}")) {
            throw new BizException("MSG_ALT_CONFIRM_INPUT");
        }
        try {
            LocalDate.parse(dateStr, BASIC_DATE);
        } catch (DateTimeParseException ex) {
            throw new BizException("MSG_ALT_CONFIRM_INPUT");
        }
    }
}
