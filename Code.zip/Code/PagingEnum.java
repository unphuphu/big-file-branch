package com.sds.seas.biz.common.paging.enums;

import lombok.Getter;

@Getter
public enum PagingEnum {
	//사업장
	selectSite_001("selectSite"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "scenCnt|SCEN_CNT,"
			+ "siteTypeCode|SITE_TYPE_CD,"
			+ "siteStateCode|SITE_STT_CD,"
			+ "siteState|SITE_STT,"
			+ "siteStateCode|SITE_STT_CD,"
			+ "industryClassification|IDST_CLSF,"
			+ "industryClassificationCode|IDST_CLSF_CD,"
			+ "siteManagerNameList|SITE_MNG_NM_LIST,"
			+ "finalModificationDTM|FNL_MDFC_DTM,"
			+ "inputDeveloperCount|INPT_DVLP_CNT,"
			+ "inputManPowerCount|INPT_MNP_CNT,"
			+ "fullTimeWorkerNumberOf|FULL_TIME_WRKR_NUM,"
	),

	// 개인보호구 관리
	equipment_001("selectComponentInfoList"
			,  "siteId|SITE_ID,"
			+ "siteNm|SITE_NM,"
			+ "groupId|GRP_ID," // ISMSDEV-8254 추가
			+ "groupName|GRP_NM," // ISMSDEV-8254 추가
			+ "sftgDivCd|SFTG_DIV_CD,"
			+ "sftgTypCd|SFTG_TYP_CD,"
			+ "sftgTypNm|SFTG_TYP_NM,"
			+ "mdlNm|MDL_NM,"
			+ "pcpnyNm|PCPNY_NM,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
	),

	// 개인보호구 지급반납
	equipment_002("selectComponentRcdbList"
			, "siteId|SITE_ID,"
			+ "siteNm|SITE_NM,"
			+ "groupId|GRP_ID," // ISMSDEV-8254 추가
			+ "groupName|GRP_NM," // ISMSDEV-8254 추가
			+ "payerNm|PAYER_NM,"
			+ "prvdDtm|PRVD_DTM,"
			+ "sftgDivCd|SFTG_DIV_CD,"
			+ "prvdSttCd|PRVD_STT_CD,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
	),

	// 방문자
	visitor_001("selectVisitor"
			, "siteId|SITE_ID,"
			+ "siteNm|SITE_NM,"
			+ "groupId|GRP_ID," // ISMSDEV-8254 추가
			+ "groupName|GRP_NM," // ISMSDEV-8254 추가
			+ "vstrNmSmry|VSTR_NM_SMRY,"
			+ "firstRegistrationUserNm|FST_RGST_USR_NM,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
			+ "vstStartDTM|VST_START_DT,"    // ISMSDEV-7625 20240523 DVO속성명변경 dt -> vstStartDTM
			+ "vstFinsDTM|VST_FINS_DT,"      // ISMSDEV-7625 20240523 DVO속성명변경 dt -> vstFinsDTM
			+ "vstrRgstSttCd|VSTR_RGST_STT_CD,"
			+ "vstrRgstSttNm|VSTR_RGST_STT_NM,"
	),

	// 방문자 출입현황
	visitor_002("selectVisitorHisList"
			, "siteId|SITE_ID,"
			+ "siteNm|SITE_NM,"
			+ "groupId|GRP_ID," // ISMSDEV-8254 추가
			+ "groupName|GRP_NM," // ISMSDEV-8254 추가
			+ "vstrNm|VSTR_NM,"
			+ "acsStartDt|acs_Start_Dt,"
	),

	selectEvltPlan_001("selectEvltPlan"
			, "groupName|GRP_NM,"
			+ "groupId|GRP_ID,"
			+ "developerName|DVLP_NM,"
			+ "evltDivCd|EVLT_DIV_CD,"
			+ "bddRqsNm|BDD_RQS_NM,"
			+ "compEvltSttCd|CFMT_SUDE_COMP_EVLT_STT_CD,"
			+ "evltRqsStartDtm|EVLT_RQS_START_DTM,"
			+ "evltRqsFinsDtm|EVLT_RQS_FINS_DTM,"
			+ "evalrTnm|EVALR_TNM,"
			+ "firstRegistrationUserName|FST_RGST_USR_NM,"
			+ "bddRqsNo|BDD_RQS_NO,"
			+ "ctrtNo|CTRT_NO,"
			+ "bddCtrtNm|BDD_CTRT_NM,"
			+ "ctrtTypeNm|CTRT_TYPE_CD,"
			+ "evltAnRt|EVLT_AN_RT,"
	),

	selectEvltItem_001("selectEvltItem"
			, "evltDivCd|EVLT_DIV_CD,"
			+ "evltMnmAmtToStr|EVLT_MNM_AMT,"
			+ "evltMxmAmtToStr|EVLT_MXM_AMT,"
			+ "cfmtStnrdEvltPt|CFMT_STNRD_EVLT_PT,"
			+ "evltRsultStnrdYn|EVLT_RSULT_STNRD_YN,"
			+ "evltItemSttNm|EVLT_ITEM_STT_NM,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
	),

	//점검 계획
	safetyInspectionPlan_001("selectSafetyInspectionPlan"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "groupId|GRP_ID," // ISMSDEV-8254 추가
			+ "groupName|GRP_NM," // ISMSDEV-8254 추가
			+ "inspectionTypeCode|ISPT_TYPE_CD,"
			+ "inspectionName|ISPT_NM,"
			+ "repeatCycleName|REPT_CYCL_NM,"
			+ "equipmentFullName|EQUIP_FULL_NM,"
			+ "inspectionStateCode|ISPT_STT_CD,"
			+ "registrationUserName|FST_RGST_USR_NM,"
			+ "registrationDateTime|FST_RGST_DTM,"
			+ "registrationUserId|FST_RGST_USR_ID,"
			+ "sceneName|SCEN_NM,"
	),

	//점검 활동
	safetyInspectionPlan_002("selectSafetyInspetionActivityList"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "groupId|GRP_ID," // ISMSDEV-8254 추가
			+ "groupName|GRP_NM," // ISMSDEV-8254 추가
			+ "inspectionTypeCode|ISPT_TYPE_CD,"
			+ "inspectionName|ISPT_NM,"
			+ "safetyInspectionItemDivisionCode|SFTY_ISPT_ITEM_DIV_CD,"
			+ "inspectionStateCode|ISPT_STT_CD,"
			+ "inspectionPlanDateTime|ISPT_PLAN_DTM,"
			+ "inspectionDateTime|ISPT_DTM,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
			+ "sceneName|SCEN_NM,"
	),

	//교육 계획
	educationPlan_001("selectEducationPlan"
			, "educationId|EDU_ID,"
			+ "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "educationTypeCode|EDU_TYPE_CD,"
			+ "educationWayCode|EDU_WAY_CD,"
			+ "educationName|EDU_NM,"
			+ "educationDTM|EDU_START_DTM,"
			+ "educationProgressStateCode|EDU_PRGS_STT_CD,"
			+ "cpleResultStateCode|CPLE_RSULT_STT_CD,"
			+ "rate|RATE,"
			+ "educationInstructorName|EDU_ISTR_NM,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
			+ "educationTargetCode|EDU_TARGET_CD,"
			+ "educationParticipants|EDU_PTCP,"
	),
	// 교육과정
	curriculum_001("selectCurriculum"
			, "curriculumId|CRCL_ID,"
			+ "educationName|EDU_NM,"
			+ "educationType|EDU_TYPE,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
			+ "onlineEducationYn|ONLN_EDU_YN,"
			+ "registrationStateCode|RGST_STT_CD,"
			+ "groupId|GRP_ID," // ISMSDEV-8660 추가
			+ "groupName|GRP_NM," // ISMSDEV-8660 추가
			+ "educationTypeCode|EDU_TYPE_CD,"// ISMSDEV-8660 추가
	),


	//위험성 평가 항목
	riskEvaluationSiteItem_001("selectRiskEvaluationSiteItem"
			, "siteId|SITE_ID,"
			+ "siteNm|SITE_NM,"
			+ "siteIds|SITE_IDS," // ISMSDEV-8254 추가
			+ "grpNm|GRP_NM,"
			+ "grpId|GRP_ID," // ISMSDEV-8254 추가
			+ "rkeEvltItemNm|RKE_EVLT_ITEM_NM,"
			+ "evltCrtrCd|EVLT_CRTR_CD,"
			+ "dtlCnt|DTL_CNT,"
			+ "rgstSttNm|RGST_STT_CD,"
			+ "firstRegistrationUserNm|FST_RGST_USR_NM,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
	),

	//체계관리
	safetyHealth_001("selectSafetyHealth"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "allCompleteYn|ALL_COMPLETE_YN,"
			+ "managementOrganizationLayoutYn|MGT_ORGL_YN,"
			+ "emergencyNetworkOfContactsYn|EMGCY_CONTAS_YN,"
			+ "managementGoalYn|MANAGE_GOAL_YN,"
			+ "healthConsultativeGroupYn|HELTH_CSGR_YN,"
			+ "healthBulletinBoardSystemYn|HELTH_BBS_YN,"
			+ "sitePersonInChargeYn|SITE_PIC_YN,"
	),


	//안전보건게시
	safetyHealthBulletinBoard_001("selectSafetyHealthBulletinBoard"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "postingDivisionCode|PSTNG_DIV_CD,"
			+ "postingTitle|PSTNG_TTL,"
			+ "inquiryCountOf|INQR_CNT,"
			+ "postingStartDate|PSTNG_START_DT,"
			+ "firstRegistrationUserName|FST_RGST_USR_NM,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
	),

	healthMshdMng_001("selectHealthMshdMngList"
			, "matNm|MAT_NM,"
			+ "supNm|SUP_NM,"
			+ "casNo|CAS_NO,"
			+ "registStartDt|FST_RGST_DTM,"
			+ "registEndDt|FST_RGST_DTM,"
			+ "revStartDt|REV_DATE,"
			+ "revEndDt|REV_DATE,"
			+ "specManaMatYn|SPEC_MANA_MAT_YN,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
	),


	//안전보건관리표준 : 20240408 ISMSDEV-7628 추가
	managementStandard_001("selectManagementStandard"
			, "managementStandardDivisionCode|MGT_STD_DIV_CD,"
			+ "managementStandardScopeDivisionCode|MGT_STD_SCP_DIV_CD,"
			+ "postingTitle|PSTNG_TTL,"
			+ "inquiryCountOf|INQR_CNT,"
			+ "firstRegistrationUserName|FST_RGST_USR_NM,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
	),


	// 위험성평가 계획/실정 목록
	riskEvaluation_001("selectRiskEvaluationResultList"
			, "siteId|SITE_ID,"
			+ "siteNm|SITE_NM,"
			+ "evltTypeCd|EVLT_TYPE_CD,"
			+ "evltTypeNm|EVLT_TYPE_NM,"
			+ "evltCrtrCd|EVLT_CRTR_CD,"
			+ "evltCrtrNm|EVLT_CRTR_NM,"
			+ "evltDvlpNmSmry|EVLT_DVLP_NM_SMRY,"
			+ "evltDvlpNmTotal|EVLT_DVLP_NM_TOTAL,"
			+ "measureTotalCnt|MEASURE_TOTAL_CNT,"
			+ "rkeEvltSttCd|RKE_EVLT_STT_CD,"
			+ "rkeEvltSttNm|RKE_EVLT_STT_NM,"
			+ "evltSchdlDt|EVLT_SCHDL_DT,"
			+ "evltNmSmry|EVLT_NM_SMRY,"
			+ "evltNmTotal|EVLT_NM_TOTAL,"
			+ "evltDt|EVLT_DT,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
			+ "evltPlanNm|EVLT_PLAN_NM,"
			+ "evltEquipNmTotal|EVLT_EQUIP_NM_TOTAL,"
			+ "rkeEvltVerNo|RKE_EVLT_VER_NO,"
	),

	//위험성 평가 조사표 항목 관리
	riskEvaluationSurveyItem_001("selectRiskEvaluationSurveyItem"
			, "surveyItemDivisionCode|SRV_ITEM_DIV_CD,"
			+ "surveyItemDivision|SRV_ITEM_DIV,"
			+ "surveyItemStatus|SRV_ITEM_STT_ORD,"
			+ "surveyItemStatusCode|SRV_ITEM_STT_CD,"
			+ "firstRegistrationUserName|FST_RGST_USR_NM,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
	),

	//전파교육목록
	riskEvaluation_002("selectRiskEvaluationEducation"
			, "eduType|EDU_TYPE,"
			+ "eduTarget|EDU_TARGET,"
			+ "eduPrgsStt|EDU_PRGS_STT_ORD,"
			+ "eduStartDtm|EDU_START_DTM,"
	),

	//전파교육 - 교육계획 불러오기
	riskEvaluation_003("selectEducationPlanNotInRiskEvaluation"
			, "eduType|EDU_TYPE,"
			+ "eduPrgsStt|EDU_PRGS_STT_ORD,"
			+ "eduStartDtm|EDU_START_DTM,"
			+ "eduNm|EDU_NM,"
			+ "eduWay|EDU_WAY,"
			+ "eduPrgsSttCd|EDU_PRGS_STT_CD,"
	),


	// 작업관리
	workInfo_001("selectWorkInfo"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "workName|WRK_NM,"
			+ "workScheduleStartDTM|WRK_SCHDL_START_DTM,"
			+ "workSchedulePeriod|WRK_SCHDL_START_PRD,"
			+ "riskGrade|RISK_GRD,"
			+ "riskGradeCode|RISK_GRD_CD,"
			+ "workStateCode|WRK_STT_CD,"
			+ "workState|WRK_STT,"
			+ "workerNum|WRKR_NUM,"
			+ "writer|WRTR,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
			+ "sceneName|SCEN_NM,"
	),

	// 작업계획
	workInfo_002("selectWorkInfo"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "workName|WRK_NM,"
			+ "workScheduleStartDTM|WRK_SCHDL_START_DTM,"
			+ "riskGrade|RISK_GRD,"
			+ "riskGradeCode|RISK_GRD_CD,"
			+ "workStateCode|WRK_STT_CD,"
			+ "workState|WRK_STT,"
			+ "workerNum|WRKR_NUM,"
			+ "writer|WRTR,"
			+ "fstRgstDtm|FST_RGST_DTM,"
			+ "inspectionPlanDate|ISPT_PLAN_DT,"
			+ "sceneName|SCEN_NM,"
	),


	// (신)작업계획
	workplan_001("selectWorkPlan"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "workName|WRK_NM,"
			+ "workPlanStateCode|WRK_PLAN_STT_CD,"
			+ "workPlanState|WRK_PLAN_STT,"
			+ "workScheduleStartDTM|WRK_SCHDL_START_DTM,"
			+ "workSchedulePeriod|WRK_SCHDL_START_PRD,"
			+ "workGradeCode|WRK_GRD_CD,"
			+ "workGrade|WRK_GRD,"
			+ "mangementPersonInChargeId|MNGT_PIC_ID,"
			+ "mangementPersonInChargeName|MNGT_PIC_NM,"
			+ "workerNum|WRKR_NUM,"
			+ "writer|WRTR,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
			+ "sceneName|SCEN_NM,"
	),

	// (신)작업허가
	workplan_002("selectWorkPlanPermission"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "workName|WRK_NM,"
			+ "workPlanStateCode|WRK_PLAN_STT_CD,"
			+ "workPlanState|WRK_PLAN_STT,"
			+ "workPermissionStateCode|WRK_PRMS_STT_CD,"
			+ "workPermissionState|WRK_PRMS_STT,"
			+ "workScheduleStartDTM|WRK_SCHDL_START_DTM,"
			+ "workSchedulePeriod|WRK_SCHDL_START_PRD,"
			+ "workGradeCode|WRK_GRD_CD,"
			+ "workGrade|WRK_GRD,"
			+ "mangementPersonInChargeId|MNGT_PIC_ID,"
			+ "mangementPersonInChargeName|MNGT_PIC_NM,"
			+ "workerNum|WRKR_NUM,"
			+ "writer|WRTR,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
			+ "sceneName|SCEN_NM,"
	),

	// 장비/설비 관리
	tool_001("selectTool"
			, "siteId|SITE_ID,"
			+ "siteNm|SITE_NM,"
			+ "groupId|GRP_ID," // ISMSDEV-8254 추가
			+ "groupName|GRP_NM," // ISMSDEV-8254 추가
			+ "equipType|equipType,"
			+ "equipmentName|EQUIP_NM,"
			+ "equipStatus|EQUIP_STT_CD,"
			+ "equipStatusNm|EQUIP_STT,"
			+ "modelName|MDL_NM,"
			+ "fstRgstDtm|FST_RGST_DTM,"
			+ "inspectionPlanDate|ISPT_PLAN_DT,"
			+ "assetYn|ASSET_YN,"
			+ "lawsDivisionNameArr|LAWS_DIV_NM_ARR,"
			+ "equipmentTypeCode|EQUIP_TYP_CD," // ISMSDEV-8722 추가
			+ "fstRgstDtm|FST_RGST_DTM," // ISMSDEV-8722 추가
	),

	tool_002("selectEquipRiskEvaluationList"
			, "evltSchdlDt|EVLT_SCHDL_DT,"
			+ "evltDt|EVLT_DT,"
			+ "rkeEvltSttCd|RKE_EVLT_STT_CD,"
	),

	// 교육계획
//	eduInfo_001("selectEducationPlan"
//			, "siteId|SITE_ID,"
//					+ "educationName|EDU_NM,"
//					+ "rate|RATE,"
//					+ "educationCompletionTime|EDU_CPLE_TM,"
//					+ "educationTypeCode|EDU_TYPE_CD,"
//					+ "educationWayCode|EDU_WAY_CD,"
//					+ "educationProgressStateCode|EDU_PRGS_STT_CD,"
//					+ "groupId|GRP_ID,"
//					+ "groupName|GRP_NM,"
//			),

	//교육이수결과상신
	eduInfo_003("selectEducationCompleteResult"
			, "eduCpleRsultTit|EDU_CPLE_RSULT_TIT,"
			+ "eduCpleRsultSttCd|EDU_CPLE_RSULT_STT_CD,"
			+ "siteName|SITE_NM,"
			+ "groupId|GRP_ID," // ISMSDEV-8254 추가
			+ "groupName|GRP_NM,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
	),

	//연간안전보건교육계획
	eduInfo_004("selectEducationPlanYearly"
			, "groupName|GRP_NM,"
			+ "groupId|GRP_ID," // ISMSDEV-8254 추가
			+ "siteName|SITE_NM,"
			+ "planYear|PLAN_YEAR,"
			+ "eduPlanYearlyStateCode|EDU_PLAN_YEARLY_STT_CD,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
			+ "companyName|CPNY_NM,"
	),

	// 협의체
	consultativeGroupActivity_001("selectConsultativeGroupActivity"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "consultativeGroupDivisionCode|CSGR_DIV_CD,"
			+ "consultativeGroupDivision|CSGR_DIV,"
			+ "operationStateCode|OPRA_STT_CD,"
			+ "operationState|OPRA_STT,"
			+ "planDTM|PLAN_DTM,"
			+ "firstRegistrationUserName|FST_RGST_USR_NM,"
			+ "practiceDTM|PRTC_DTM,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
	),

	// 신고> 인적/물적 사고 목록
	accident_001("selectAccident"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "accidentDivisionCode|ACDT_DIV_CD,"
			+ "accidentDivision|ACDT_DIV,"
			+ "accidentLevelCode|ACDT_LEVEL_CD,"
			+ "accidentLevel|ACDT_LEVEL,"
			+ "accidentGenerationDateTime|ACDT_GNRT_DTM,"
			+ "accidentHarmDamageCount|ACDT_HADG_CNT,"
			+ "accidentHarmDamagePersonCount|ACDT_HADG_PER_CNT,"
			+ "accidentHarmDamagePhysicalCount|ACDT_HADG_PHY_CNT,"
			+ "dohAcdtYn|DOH_ACDT_YN,"
			+ "accidentMeasureCount|ACDT_MEAS_CNT,"
			+ "accidentProgressStateCode|ACDT_PRGS_STT_CD,"
			+ "accidentProgressState|ACDT_PRGS_STT,"
			+ "firstDeclarerName|FST_DCLR_NM,"
			+ "accidentDeclarationDatetime|ACDT_DCDD,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
			+ "ocpAcdtDivCd|OCP_ACDT_DIV_CD,"
			+ "ocpAcdtDiv|OCP_ACDT_DIV,"
			+ "victmDivCd|VICTM_DIV_CD,"
	),

	accident_002("selectAccidentVictimStatus"
			, "grpNm|GRP_NM,"
			+ "grpId|GRP_ID,"
			+ "ocpAcdtDivCd|OCP_ACDT_DIV_CD,"
			+ "victmDivCd|VICTM_DIV_CD,"
			+ "victmCpnyNm|VICTM_CPNY_NM,"
			+ "acdtGnrtDtm|ACDT_GNRT_DTM,"
			+ "dohAcdtYn|DOH_ACDT_YN,"
			+ "ocpAcdtDiv|OCP_ACDT_DIV,"
			+ "disasterClassificationCode|DSTR_CLSS_CD,"
			+ "disasterClassificationtypeIA|APVL_REVW_STT_CD,"
	),

	// 신규 > 위험요인
	riskCause_001("selectRiskCause"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM," // ISMSDEV-8254 추가
			+ "disasterType|DSTR_TYPE,"
			+ "disasterTypeCode|DSTR_TYPE_CD,"
			+ "riskCauseTitle|RISK_CUSE_TTL,"
			+ "riskCauseState|RISK_CUSE_STT,"
			+ "riskCauseStateCode|RISK_CUSE_STT_CD,"
			+ "firstRegistrationUserName|FST_RGST_USR_NM,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
			+ "measurePersonInChargeIdUserName|MEAS_PIC_ID_USR_NM,"
			+ "measureCompletionDTM|MEAS_CPLT_DTM,"
			+ "inquiryCountOf|INQR_CNT,"
			+ "workStopYn|WORK_STOP_YN,"
			+ "cnsgDcvYn|CNSG_DCV_YN,"
			+ "victmDivCd|USR_CD,"
	),

	riskCause_002("selectRiskCauseRate"
			, "siteId|SITE_ID,"
			+ "siteNm|SITE_NM,"
			+ "grpId|GRP_ID,"
			+ "grpNm|GRP_NM,"
			+ "riskRank|RISK_RANK,"
			+ "riskCount|RISK_COUNT,"
			+ "fstDclrId|FST_DCLR_ID,"
			+ "usrNm|USR_NM,"
	),


	// 조치 관리
	measure_001("selectMeasure"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "subModuleCode|SMDLE_CD,"
			+ "subModule|SMDLE,"
			+ "measurePlanName|MEAS_PLAN_NM,"
			+ "measureCauseGenerationDate|MEAS_CAUS_GNRT_DT,"
			+ "measureScheduleDate|MEAS_SCHDL_DT,"
			+ "measurePersonInChargeIdUserName|MEAS_PIC_ID_USR_NM,"
			+ "measureCompletionDateTime|MEAS_CPLT_DTM,"
			+ "measureStatusCode|MEAS_STT_CD,"
			+ "measureStatus|MEAS_STT,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
	),

	aceess_001("selectAccessInfo"
			, "accessPlaceName|ACS_PLAC_NM,"
			+ "accessStartDTM|ACS_START_DTM,"
			+ "accessFinishDTM|ACS_FINS_DTM,"
	),

	rcdb_001("selectComponentRcdbUserHisList"
			, "siteNm|SITE_NM,"
			+ "prvdCfrmDtm|PRVD_CFRM_DTM,"
			+ "returnCfrmDtm|RETURN_CFRM_DTM,"
			+ "prvdSttNm|PRVD_STT_NM,"
	),

	educationHis_001("selectEducation"
			, "educationType|EDU_TYPE,"
			+ "educationWay|EDU_WAY,"
			+ "educationName|EDU_NM,"
			+ "completionYn|CPLE_YN,"
			+ "educationStartDateAndTime|EDU_START_DTM,"
	),

	// 점검 항목
	inspectionItem_001("selectInspectionItemList"
			, "siteName|SITE_NM,"
			+ "grpName|GRP_NAME,"
			+ "siteId|SITE_ID," // ISMSDEV-8254 추가
			+ "grpId|GRP_ID,"   // ISMSDEV-8254 추가
			+ "safetyInspectionItemName|SFTY_ISPT_ITEM_NM,"
			+ "safetyInspectionItemDivisionCode|SFTY_ISPT_ITEM_DIV_CD,"
			+ "safetyInspectionItemDivision|SFTY_ISPT_ITEM_DIV,"
			+ "registrationStateCode|RGST_STT_CD,"
			+ "registrationState|RGST_STT,"
			+ "registrationDateTime|RGST_DTM,"
	),

	// ISMSDEV-8076 20240926 medicalCheckupManagementTargetYn 검진관리대상여부 추가
	developer_001("selectDeveloper"
			, "companyName|CPNY_NM,"
			+ "corporateRegistrationNumber|CRNO,"
			+ "industryClassification|IDST_CLSF,"
			+ "industryClassificationCode|IDST_CLSF_CD,"
			+ "siteNameArr|SITE_NM_ARR,"
			+ "siteIdArr|SITE_ID_ARR,"
			+ "siteName|SITE_NM,"
			+ "siteId|SITE_ID,"
			+ "contractNumberOf|CTRT_NUM,"
			+ "inputEmployeeNumberOf|INPT_EMP_NUM,"
			+ "inputState|INPT_STT,"
			+ "inputStateCode|INPT_STT_CD,"
			+ "medicalCheckupManagementTargetYn|MECH_MGT_TARGET_YN,"
			+ "finalModificationDTM|FNL_MDFC_DTM,"
	),

	contract_001("selectContract"
			, "companyName|CPNY_NM,"
			+ "contractTypeCode|CTRT_TYPE_CD,"
			+ "contractType|CTRT_TYPE,"
			+ "contractNumber|CTRT_NO,"
			+ "contractName|CTRT_NM,"
			+ "contractStateCode|CTRT_STT_CD,"
			+ "contractState|CTRT_STT,"
			+ "contractStartDate|CTRT_START_DT,"
			+ "contractFinishDate|CTRT_FINS_DT,"
			+ "registrationUserName|FST_RGST_USR_NM,"
			+ "registrationDateTime|FST_RGST_DTM,"
			+ "siteId|SITE_ID,"
			+ "siteNameArr|SITE_NM_ARR,"
			+ "siteIdArr|SITE_ID_ARR,"
			+ "siteMngNm|SITE_MNG_NM,"
			+ "pmName|PM_NM,"
			+ "contractStateCode|CTRT_STT_CD,"
			+ "pmGroupName|PM_GRP_NM,"
			+ "workerNumber|WRKR_NUM,"
	),

	contract_002("selectContractExcelDownload"
			, "companyName|CPNY_NM,"
			+ "contractTypeCode|CTRT_TYPE_CD,"
			+ "contractType|CTRT_TYPE,"
			+ "contractNumber|CTRT_NO,"
			+ "contractName|CTRT_NM,"
			+ "contractStateCode|CTRT_STT_CD,"
			+ "contractState|CTRT_STT,"
			+ "contractStartDate|CTRT_START_DT,"
			+ "contractFinishDate|CTRT_FINS_DT,"
			+ "registrationUserName|FST_RGST_USR_NM,"
			+ "registrationDateTime|FST_RGST_DTM,"
			+ "siteId|SITE_ID,"
			+ "siteNameArr|SITE_NM_ARR,"
			+ "siteIdArr|SITE_ID_ARR,"
			+ "siteMngNm|SITE_MNG_NM,"
			+ "pmName|PM_NM,"
			+ "contractStateCode|CTRT_STT_CD,"
			+ "pmGroupName|PM_GRP_NM,"
			+ "workerNumber|WRKR_NUM,"
	),

	// ISMSDEV-8227 20251107 [보건] 작업환경 측정 
	workEnvMeasure_001("selectWorkEnvMeasure"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
			+ "measurementPlanDt|MSRM_PLAN_DT,"
			+ "measurementStateCode|MSRM_STT_CD,"
			+ "measurementState|MSRM_STT,"
			+ "measurementCompanyName|MSRM_CPNY_NM,"
			+ "resultExceedYN|RSULT_ECXD_YN,"
			+ "resultInputYN|RSULT_INPUT_YN,"
			+ "resultImprovementPlanExistedYN|RSULT_IPRV_PLAN_EXIST_YN,"
			+ "finalModificationUserName|FNL_MDFC_USR_NM,"
	),

	workEnvMeasure_002("selectWorkEnvMeasureHarmAgentManage"
			, "harmnessAgentMajorcategoryName|HARM_AGNT_MCATG_NM,"
			+ "harmnessAgentSubcategoryName|HARM_AGNT_SCATG_NM,"
			+ "harmnessAgentSubdivisionName|HARM_AGNT_SDIV_NM,"
			+ "harmnessAgentName|HARM_AGNT_NM,"
			+ "casNumberValue|CAS_NO_VAL,"
			+ "useYN|USE_YN,"
	),

	TBMDelivery_001("selectTBMDelivery"
			, "siteId|SITE_ID,"
			+ "groupName|GRP_NM,"
			+ "siteNames|SITE_NMS,"
			+ "siteIds|SITE_IDS," // ISMSDEV-8254 추가
			+ "inquiryScopeOrganizationId|INQR_SCP_ORGZ_ID," // ISMSDEV-8254 추가
			+ "title|TTL,"
			+ "inquiryCountOf|INQR_CNT,"
			+ "noticeStartDate|NTCE_START_DT,"
			+ "noticeFinishDate|NTCE_FINS_DT,"
			+ "userName|USR_NM,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
	),

	TBMPlan_001("selectTBMPlan"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "companyName|CPNY_NM,"
			+ "processCode|PRCSS_CD,"
			+ "processName|PRCSS_NM,"
			+ "tbmPlanStateCode|TBM_PLAN_STT_CD,"
			+ "tbmPlanStateName|TBM_PLAN_STT_NM,"
			+ "activityDate|ATV_START_DT,"
			+ "endDate|ATV_END_DT,"
			+ "activityUserId|ATV_USR_ID,"
			+ "activityUserName|ATV_USR_NM,"
			+ "firstRegistrationUserName|FST_RGST_USR_NM,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
			+ "workId|WRK_ID,"
			+ "workName|WRK_NM,"
	),

	TBMActivity_001("selectTBMActivity"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "companyNm|CPNY_NM,"
			+ "processCode|PRCSS_CD,"
			+ "process|PRCSS,"
			+ "activityImplementationYn|ATV_IMPL_YN,"
			+ "participationPersonsNumberOf|PRTCPT_PRSNS_NUM,"
			+ "activityStateCode|ATV_STT_CD,"
			+ "activityState|ATV_STT,"
			+ "activityPlanDTM|ATV_PLAN_DTM,"
			+ "userName|USR_NM,"
			+ "activityUserName|ATV_USR_NM,"
			+ "activityStartDTM|ATV_START_DTM,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
			+ "activityUserId|ATV_USR_ID,"
			+ "firstRegistrationUserName|FST_RGST_USR_NM,"
			+ "planName|PLAN_NM,"
	),

	// 직원 관리 - 직원 목록
	employee_001("selectEmployee"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
			+ "userId|USR_ID,"
			+ "userName|USR_NM,"
			+ "cellularPhone|CP,"
			+ "siteCnt|SITE_CNT,"
			+ "medicalCheckupDate|MECH_DT,"
			+ "educationTime|EDU_TM,"
			+ "license|LICS,"
			+ "managerYn|MNGR_YN,"
			+ "approvalYn|APRV_YN,"
			+ "inresidenceStateCode|IRSD_STT_CD,"
			+ "inresidenceState|IRSD_STT,"
	),

	// 직원 관리 - 초대 목록
	employeeInvite_001("selectEmployeeInvite"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "fullName|FLNM,"
			+ "userId|USR_ID,"
			+ "invitingUserId|INVITING_USR_ID,"
			+ "invitationCode|IVTN_CD,"
			+ "groupId|GRP_ID,"
			+ "cellularPhone|CP,"
			+ "groupName|GRP_NM,"
			+ "invitationStateCode|IVTN_STT_CD,"
			+ "invitationState|IVTN_STT,"
			+ "firstRegistrationUserName|FST_RGST_USR_NM,"
			+ "finalModificationDTM|FNL_MDFC_DTM,"
	),
	manpower_001("selectManpower"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "loginId|LOGIN_ID,"
			+ "userId|USR_ID,"
			+ "userName|USR_NM,"
			+ "cellularPhone|CP,"
			+ "ctrtNo|CTRT_NO,"
			+ "developerId|DVLP_ID,"
			+ "companyName|CPNY_NM,"
			+ "inputRoleName|INPT_ROL,"
			+ "inputRoleCode|INPT_ROL_CD,"
			+ "inputStartDate|INPT_START_DT,"
			+ "inputFinishDate|INPT_FINS_DT,"
			+ "userAcoStateCode|USR_ACO_STT_CD,"
			+ "userAcoState|USR_ACO_STT,"
			+ "inputStateCode|INPT_STT_CD,"
			+ "inputUserAcoState|INPT_ACO_STT,"
			+ "finalModificationDTM|FNL_MDFC_DTM,"
	),

	//공지사항
	boardNotice_001("selectBoardNotice"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
			+ "userName|FST_RGST_USR_NM,"
			+ "annNoticeObjTitle|NOTICOBJ_TXT_TTL,"
			+ "annNoticeObjContent|NOTICOBJ_TXT_CNTN,"
			+ "postingRange|PSTNG_RANGE,"
			+ "postingAlias|PSTNG_ALIAS,"
			+ "postingPeriod|PSTNG_PRD,"
			+ "noticeType|NTC_TPE,"
			+ "postingRangeCode|PSTNG_RNG_CD,"
			+ "firstRegistrationUserId|FST_RGST_USR_ID,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
			+ "registrationUserName|FST_RGST_USR_NM,"
			+ "registrationDateTime|FST_RGST_DTM,"
	),

	invite_001("selectInvite"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "invitationId|IVTN_ID,"
			+ "loginId|LOGIN_ID,"
			+ "userId|USR_ID,"
			+ "invitingUserId|INVITING_USR_ID,"
			+ "fullName|FLNM,"
			+ "cellularPhone|CP,"
			+ "developerId|DVLP_ID,"
			+ "developerName|DVLP_NM,"
			+ "inputRoleCode|INPT_ROL_CD,"
			+ "inputRole|INPT_ROL,"
			+ "inputStartDate|INPT_START_DT,"
			+ "inputFinishDate|INPT_FINS_DT,"
			+ "invitationStateCode|IVTN_STT_CD,"
			+ "invitationState|IVTN_STT,"
			+ "firstRegistrationUserName|FST_RGST_USR_NM,"
			+ "finalModificationDTM|FNL_MDFC_DTM,"
	),

	// 첫번째 탭, 미결함
	approval_001("notDecidedApprovalListPc"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "aprvCntn|APRV_CNTN,"
			+ "aprvTtl|APRV_TTL,"
			+ "aprvDratDtm|APRV_DRAT_DTM,"
			+ "usrNm|USR_NM,"
			+ "presAprvrtTypeCd|PRES_APRVRT_TYPE_CD,"
	),

	// 두번째 탭, 기결함
	approval_002("decidedApprovalListPc"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "aprvCntn|APRV_CNTN,"
			+ "aprvTtl|APRV_TTL,"
			+ "aprvDratDtm|APRV_DRAT_DTM,"
			+ "usrNm|USR_NM,"
			+ "aprvCpltDtm|APRV_CPLT_DTM,"
			+ "aprvPrgsSttCd|APRV_PRGS_STT_CD,"
	),

	// 세번째 탭, 상신함
	approval_003("iReportApprovalListPc"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "aprvCntn|APRV_CNTN,"
			+ "aprvTtl|APRV_TTL,"
			+ "aprvDratDtm|APRV_DRAT_DTM,"
			+ "usrNm|USR_NM,"
			+ "aprvCpltDtm|APRV_CPLT_DTM,"
			+ "aprvPrgsSttCd|APRV_PRGS_STT_CD,"
	),

	// 네번째 탭, 통보함
	approval_004("noticeApprovalListPc"
			, "siteId|SITE_ID,"
			+ "siteName|SITE_NM,"
			+ "aprvCntn|APRV_CNTN,"
			+ "aprvTtl|APRV_TTL,"
			+ "aprvDratDtm|APRV_DRAT_DTM,"
			+ "usrNm|USR_NM,"
			+ "aprvCpltDtm|APRV_CPLT_DTM,"
			+ "aprvPrgsSttCd|APRV_PRGS_STT_CD,"
	),

	// 출력 리포트 목록 조회
	selectPrintList_001("selectReportPrintList"
			, "siteId|SITE_ID,"
			+ "siteNm|SITE_NM,"
			+ "taskActvDt|TASK_ACTV_DT,"
			+ "prntCrtDt|PRNT_CRT_DT,"
			+ "reportId|RPT_ID,"
			+ "dvlpNm|DVLP_NM,"
			+ "documentTitle|DOC_TTL,"
	),
	//단기작업자
	selectDailyManpower_001("selectDailyManpower"
			, "siteId|SITE_ID,"
			+ "siteNm|SITE_NM,"
			+ "dvlpId|DVLP_ID,"
			+ "dvlpNm|CPNY_NM,"
			+ "firstRegistrationDTM|FST_RGST_DTM,"
			+ "usrNm|USR_NM,"
			+ "cp|CP,"
	),

	selectPunishmentActCompliance_001("selectPunishmentActComplianceInfo"
			, "groupId|GRP_ID,"
			+ "groupName|GRP_NM,"
			+ "siteName|SITE_NM,"
			+ "sapAcsYear|SAP_ACS_YEAR,"
			+ "sapAcsHlfYearCd|SAP_ACS_HLF_YEAR_CD,"
			+ "sapAcsFstCheckYn|SAP_ACS_FST_CHCK_YN,"
			+ "sapAcsSecCheckYn|SAP_ACS_SEC_CHCK_YN,"
	)
	;


	private final String processName;

	private final String matchColumn;

	PagingEnum(String processName, String matchColumn) {
		this.processName = processName;
		this.matchColumn = matchColumn;
	}
}